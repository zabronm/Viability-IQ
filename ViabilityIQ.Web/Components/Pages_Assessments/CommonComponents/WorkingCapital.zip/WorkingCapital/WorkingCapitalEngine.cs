﻿namespace ViabilityIQ.Web.Components.Pages_Assessments.CommonComponents.WorkingCapital
{
    public class WorkingCapitalEngine
    {

        public static void GenerateDistribution(WorkingCapitalModule module)
        {
            module.Distribution.Clear();
            module.MonthlyTotals.Clear();
            module.DistributionTotals.Clear();
            module.TotalInvoiced = 0;
            module.TotalDistributed = 0;

            var bucketTotals = new List<decimal>();
            for (int i = 0; i < 4; i++)
            {
                bucketTotals.Add(0);
            }

            //decimal invoice = startingInvoice;
            foreach (var value in module.MonthlyValues)
            {
                var row = new WorkingCapitalDistributionRow();

                row.Month = value.Month;
                row.Invoiced = value.InvoicedAmount;

                row.Values.Add(value.InvoicedAmount * module.Profile.Days0To30 / 100m);
                row.Values.Add(value.InvoicedAmount * module.Profile.Days30To60 / 100m);
                row.Values.Add(value.InvoicedAmount * module.Profile.Days60To90 / 100m);
                row.Values.Add(value.InvoicedAmount * module.Profile.Days90To120 / 100m);

                module.Distribution.Add(row);
                module.TotalInvoiced += row.Invoiced;
                module.TotalDistributed += row.Total;

                for (int i = 0; i < row.Values.Count; i++)
                {
                    bucketTotals[i] += row.Values[i];
                }
                module.DistributionTotals.AddRange(bucketTotals);
                module.MonthlyTotals.Add(row.Total);

                //module.Distribution.Add(row);
                //module.MonthlyTotals.Add(row.Total);
            }

            module.Summary.Outstanding =    module.Distribution.Sum(x => x.Total);

            module.Summary.Percentage =                module.TotalInvoiced == 0                    ? 0                    : Math.Round(                        module.Summary.Outstanding /                        module.TotalInvoiced * 100m,                        2);

            module.Summary.Days =                module.TotalInvoiced == 0                    ? 0                    : Math.Round(                        module.Summary.Outstanding /                        module.TotalInvoiced * 30m,                        1);

        }
    }
}

