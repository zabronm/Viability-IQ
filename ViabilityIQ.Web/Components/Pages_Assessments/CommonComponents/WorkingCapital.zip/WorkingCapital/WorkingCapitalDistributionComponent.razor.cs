﻿using Microsoft.AspNetCore.Components;

namespace ViabilityIQ.Web.Components.Pages_Assessments.CommonComponents.WorkingCapital
{
    public partial class WorkingCapitalDistributionComponent
    {
        //---------------------------------------------------------
        // Parameters
        //---------------------------------------------------------

        [Parameter]        public WorkingCapitalModule Module { get; set; } = new();

        //---------------------------------------------------------
        // Computed
        //---------------------------------------------------------
       
        private string PanelCss => Module.Theme == "debtors" ? "wcm-debtors" : "wcm-creditors";

        private string HeaderCss => Module.Theme == "debtors" ? "wcm-header-debtors" : "wcm-header-creditors";

        private bool IsProfileValid =>     Math.Abs(Module.Profile.Total - 100m) < 0.001m;

        private void Recalculate()
        {
            WorkingCapitalEngine.GenerateDistribution(Module);
            StateHasChanged();
        }

        private void ResetProfile()
        {
            Module.Profile.Days0To30 = 60;
            Module.Profile.Days30To60 = 20;
            Module.Profile.Days60To90 = 14;
            Module.Profile.Days90To120 = 6;

            Recalculate();
        }

    }
}

