namespace ViabilityIQ.Web.Components.Pages_Assessments.ProjectionComponents;

public partial class CashflowKPICardsComponent : IndependentCashflowProjectionComponent;
