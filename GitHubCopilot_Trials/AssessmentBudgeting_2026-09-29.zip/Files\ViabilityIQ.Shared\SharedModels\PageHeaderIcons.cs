﻿namespace ViabilityIQ.Shared.SharedModels
{
    public enum PageType
    {
        Banks,
        Dashboards,
        Assessments,
        Assessment,
        Businesses,
        ClientTypes,
        Contacts,
        Communication,
        Settings,
        Help,
        Users,
        UserGroups,
        Account,
        ActivityLog,
        Suggestions,
        Loans,
        Debtors,
        Creditors,
        Reports,
        ProductCategory,
        Product,
        Province,
        Company,
        Sectors,
        Assets,
        Expenses,
        Stock,
        VAT,
        Sales,
        LoanTypes,
        IncomeTypes,
        ExpenseTypes,
        Budgets,
        Home,
    }

    public static class PageHeaderIcons
    {
        
        /// Global translation dictionary matching a PageType enum to its respective Bootstrap Icon class string.
        
        public static string GetIconClass(PageType pageType) => pageType switch
        {
            PageType.Home => "bi bi-house-door-fill",
            PageType.Dashboards => "bi bi-grid",
            PageType.Settings => "bi bi-gear",
            PageType.Users => "bi bi-people-fill",
            PageType.Assessments => "bi bi-stack",
            PageType.Assessment => "bi bi-pin-angle-fill",
            PageType.Account => "bi bi-person-vcard-fill",
            PageType.Communication => "bi bi-bell-fill",
            PageType.Businesses => "bi bi-buildings",
            PageType.Contacts => "bi bi-person-lines-fill",
            PageType.Help => "bi bi-question-circle-fill",
            PageType.Suggestions => "bi bi-person-raised-hand",
            PageType.Loans => "bi bi-umbrella-fill",
            PageType.Creditors => "bi bi-incognito",
            PageType.Debtors => "bi bi-briefcase",
            PageType.ActivityLog => "bi bi-calendar3",
            PageType.UserGroups => "bi bi-people",
            PageType.Reports => "bi bi-clipboard2-data",
            PageType.Banks => "bi bi-bank",
            PageType.Product => "bi bi-box-seam-fill",
            PageType.ProductCategory => "bi bi-diagram-3-fill",
            PageType.Company => "bi bi-building-gear",
            PageType.Province => "bi bi-geo-alt-fill",
            PageType.Sectors => "bi bi-inboxes-fill",
            PageType.Assets => "bi bi-suitcase-lg-fill",
            PageType.Sales => "bi bi-graph-up-arrow",
            PageType.Expenses => "bi bi-wallet2",
            PageType.Stock => "bi bi-boxes",
            PageType.VAT => "bi bi-bug",
            PageType.LoanTypes => "bi bi-umbrella-fill",
            PageType.ClientTypes => "bi bi-people-fill",
            PageType.IncomeTypes => "bi bi-diagram-3-fill",
            PageType.ExpenseTypes => "bi bi-palette2",   
            PageType.Budgets => "bi bi-calculator",

            _ => "bi bi-circle"
        };
    }
}