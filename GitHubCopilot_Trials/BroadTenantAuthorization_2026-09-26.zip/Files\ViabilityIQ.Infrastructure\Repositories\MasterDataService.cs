﻿using Dapper;
using Dapper.Contrib.Extensions;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ViabilityIQ.Application.Dtos;
using ViabilityIQ.Application.Interfaces;
using ViabilityIQ.Infrastructure.DbFactory;
using ViabilityIQ.Shared.DataModels;
using ViabilityIQ.Shared.DataModels.SecurityDataModels;
using ViabilityIQ.Shared.SharedModels;



namespace ViabilityIQ.Infrastructure.Repositories
{
    public class MasterDataService
    {
        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly ISessionService _sessionService;
        private readonly IActivityLogWriter _activityLogWriter;
        private readonly ITenantAuthorizationService _tenantAuthorizationService;


        //private readonly ILogger<MasterDataService> _logger;
        //private readonly IMemoryCache _cache;
        private readonly TimeSpan _cacheDuration = TimeSpan.FromHours(1); // Cache duration can be adjusted as needed
        private readonly string _cacheKey = "MasterData";
        private readonly object _cacheLock = new();
        private readonly object _lock = new();


        //============ CONSTRUCTOR  ==============
        public MasterDataService(
                               IDbConnectionFactory connectionFactory,
                               ISessionService sessionService,
                               IActivityLogWriter activityLogWriter,
                               ITenantAuthorizationService tenantAuthorizationService)
        {
            _dbConnectionFactory = connectionFactory;
            _sessionService = sessionService;
            _activityLogWriter = activityLogWriter;
            _tenantAuthorizationService = tenantAuthorizationService;
        }


        #region SQL Identifier Validation  and SafeIdentified methods      
        /// Validates a SQL identifier (table name, field name, schema name).
        /// Only letters, numbers and underscores are permitted.          
        private static void ValidateSqlIdentifier(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier))
                throw new ArgumentException("SQL identifier cannot be empty.");

            if (!Regex.IsMatch(identifier, @"^[A-Za-z_][A-Za-z0-9_]*$"))
                throw new ArgumentException(
                    $"Invalid SQL identifier '{identifier}'.");
        }

        private static string SafeIdentifier(string identifier)
        {
            ValidateSqlIdentifier(identifier);

            return $"[{identifier}]";
        }
        #endregion


        #region Bank CRUD methods original
        //-------BANK CRUD OPERATIONS-------
        public async Task<Bank?> GetBankByIdAsync(long bankId) => await _dbConnectionFactory.CreateConnection().GetAsync<Bank>(bankId);// Implement caching logic here if needed

        public async Task<IEnumerable<Bank>> GetAllBanksAsync()
        {
            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                var banks = await connection.GetAllAsync<Bank>();
                return banks.OrderBy(b => b.BankName).ToList();
            }
            catch (Exception ex)
            {
                // Log the exception (ex) as needed
                return null;
            }

        }

        public async Task<bool> SaveBankAsync(Bank bank)
        {
            ArgumentNullException.ThrowIfNull(bank);

            using var connection = _dbConnectionFactory.CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var isCreate = bank.BankId == 0;
                long entityId;
                bool saved;

                if (isCreate)
                {
                    bank.CreatedDate = DateTime.UtcNow;
                    bank.CreatedBy = _sessionService.UserId;
                    bank.Active = true;
                    entityId = await connection.InsertAsync(bank, transaction);
                    saved = entityId > 0;
                }
                else
                {
                    bank.ModifiedDate = DateTime.UtcNow;
                    bank.ModifiedBy = _sessionService.UserId;
                    entityId = bank.BankId;
                    saved = await connection.UpdateAsync(bank, transaction);
                }

                if (!saved)
                {
                    transaction.Rollback();
                    return false;
                }

                await _activityLogWriter.RecordAsync(
                    new ActivityLogWriteRequest
                    {
                        Action = isCreate ? ActivityAction.Create : ActivityAction.Update,
                        EntityType = nameof(Bank),
                        EntityId = entityId,
                        EntityName = bank.BankName,
                        Module = "Master Data",
                        Page = _sessionService.CurrentPage,
                        Remarks = $"{(isCreate ? "Created" : "Updated")} bank record."
                    },
                    connection,
                    transaction);

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }




        public async Task<bool> DeleteBankAsync(Bank bank)
        {
            ArgumentNullException.ThrowIfNull(bank);

            using var connection = _dbConnectionFactory.CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var deleted = await connection.DeleteAsync(bank, transaction);
                if (!deleted)
                {
                    transaction.Rollback();
                    return false;
                }

                await _activityLogWriter.RecordAsync(
                    new ActivityLogWriteRequest
                    {
                        Action = ActivityAction.Delete,
                        EntityType = nameof(Bank),
                        EntityId = bank.BankId,
                        EntityName = bank.BankName,
                        Module = "Master Data",
                        Page = _sessionService.CurrentPage,
                        Remarks = "Deleted bank record."
                    },
                    connection,
                    transaction);

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }


        #endregion

        #region LoanType CRUD methods Original ==========

        //-------LOAN TYPE CRUD OPERATIONS-------
        public async Task<LoanType?> GetLoanTypeByIdAsync(long loanTypeId) => await _dbConnectionFactory.CreateConnection().GetAsync<LoanType>(loanTypeId);

        public async Task<IEnumerable<LoanType>> GetAllLoanTypesAsync()
        {
            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                var loanTypes = await connection.GetAllAsync<LoanType>();
                return loanTypes.OrderBy(l => l.LoanTypeName).ToList();
            }
            catch (Exception ex)
            {
                // Log the exception (ex) as needed
                return null;
            }
        }


        //=============  SAVE LOAN SPECIFICATION  ==============
        public async Task<bool> SaveLoanTypeAsync(LoanType loanType)
        {
            ArgumentNullException.ThrowIfNull(loanType);

            using var connection = _dbConnectionFactory.CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var isCreate = loanType.LoanTypeId == 0;
                long entityId;
                bool saved;

                if (isCreate)
                {
                    loanType.CreatedDate = DateTime.UtcNow;
                    loanType.CreatedBy = _sessionService.UserId;
                    loanType.Active = true;
                    entityId = await connection.InsertAsync(loanType, transaction);
                    saved = entityId > 0;
                }
                else
                {
                    loanType.ModifiedDate = DateTime.UtcNow;
                    loanType.ModifiedBy = _sessionService.UserId;
                    entityId = loanType.LoanTypeId;
                    saved = await connection.UpdateAsync(loanType, transaction);
                }

                if (!saved)
                {
                    transaction.Rollback();
                    return false;
                }

                await _activityLogWriter.RecordAsync(
                    new ActivityLogWriteRequest
                    {
                        Action = isCreate ? ActivityAction.Create : ActivityAction.Update,
                        EntityType = nameof(LoanType),
                        EntityId = entityId,
                        EntityName = loanType.LoanTypeName,
                        Module = "Master Data",
                        Page = _sessionService.CurrentPage,
                        Remarks = $"{(isCreate ? "Created" : "Updated")} loan type record."
                    },
                    connection,
                    transaction);

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        //==== SPECIFIC DELETE LOAN TYPE METHOD =====
        public async Task<bool> DeleteLoanTypeAsync(LoanType loanType)
        {
            ArgumentNullException.ThrowIfNull(loanType);

            using var connection = _dbConnectionFactory.CreateConnection();
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                var deleted = await connection.DeleteAsync(loanType, transaction);
                if (!deleted)
                {
                    transaction.Rollback();
                    return false;
                }

                await _activityLogWriter.RecordAsync(
                    new ActivityLogWriteRequest
                    {
                        Action = ActivityAction.Delete,
                        EntityType = nameof(LoanType),
                        EntityId = loanType.LoanTypeId,
                        EntityName = loanType.LoanTypeName,
                        Module = "Master Data",
                        Page = _sessionService.CurrentPage,
                        Remarks = "Deleted loan type record."
                    },
                    connection,
                    transaction);

                transaction.Commit();
                return true;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }



        //================= ASSESSMENT LOANS CRUD OPERATIONS ==============================

        public async Task<AssessmentLoanDto?> GetAssessmentLoanByIdAsync(long assessmentLoanId)
        {
            using var connection = _dbConnectionFactory.CreateConnection();
            var assessmentId = await connection.QuerySingleOrDefaultAsync<long?>(
                """
                SELECT AssessmentId
                FROM vw_assessment_loans_list
                WHERE AssessmentLoanId = @AssessmentLoanId;
                """,
                new { AssessmentLoanId = assessmentLoanId });
            if (!assessmentId.HasValue)
            {
                return null;
            }

            await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                assessmentId.Value, TenantRecordAccess.Read);
            return await connection.GetAsync<AssessmentLoanDto>(assessmentLoanId);
        }


        public async Task<IEnumerable<AssessmentLoanDto>> GetAssessmentLoansByIdAsync(long assessmentId)
        {
            await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                assessmentId, TenantRecordAccess.Read);
            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                const string sql = @"SELECT  AssessmentLoanId, 
                     AssessmentId, 
                     LoanDate, 
                     LoanTypeName, 
                     BankName, 
                     LoanAmount, 
                     LoanBalanceAtAssessmentDate, 
                     InterestRatePerAnnum, 
                     RepaymentPeriodMonths, 
                     MinimumRepaymentAmount, 
                     ActualRepaymentAmount, 
                     Active
                     FROM vw_assessment_loans_list
                     WHERE AssessmentId = @AssessmentId";

                return await connection.QueryAsync<AssessmentLoanDto>(
                    sql, new
                    {
                        AssessmentId = assessmentId
                    });

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion 




        #region generic methods to get 1 annd LIST record/s passing a formatted SQL statement with 1 field parameter

        //================= GENERIC DTO READING METHODS, (1)READ 1 RECORD AND  (2) READ LIST F RECORDS ==============================
        //================= suitable for reading views into dtos  ===================================================================
        public async Task<T?> GetByIdAsync<T>(long id, string? sql = null, string paramName = "Id") where T : class
        {
            using var connection = _dbConnectionFactory.CreateConnection();

            if (string.IsNullOrWhiteSpace(sql))      // If no custom SQL is supplied, default to the ORM's direct primary key mapping method
            {
                var directResult = await connection.GetAsync<T>(id);
                await AuthorizeReturnedEntityAsync(directResult, TenantRecordAccess.Read);
                return directResult;
            }

            var parameters = new Dictionary<string, object> { { paramName, id } };  // Dynamic parameter mapping for explicit query structures
            await AuthorizeAssessmentParametersAsync(
                sql, parameters, TenantRecordAccess.Read);
            var result = await connection.QueryFirstOrDefaultAsync<T>(sql, parameters);
            await AuthorizeReturnedEntityAsync(result, TenantRecordAccess.Read);
            return result;
        }

        public async Task<IEnumerable<T>> GetListByIdAsync<T>(long id, string sql, string paramName = "Id") where T : class
        {
            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                var parameters = new Dictionary<string, object> { { paramName, id } };   // Dynamically assigns the tracking value to your specific query parameter name
                await AuthorizeAssessmentParametersAsync(
                    sql, parameters, TenantRecordAccess.Read);
                var results = (await connection.QueryAsync<T>(sql, parameters)).AsList();
                await AuthorizeReturnedEntitiesAsync(results, TenantRecordAccess.Read);
                return results;
            }
            catch (Exception)
            {
                // Maintains your current exception bubble up strategy
                throw;
            }
        }

        #endregion

        #region ===== 2 methods to get a single record based on one or multiple fied conditions ======================

        //===== usage examples =================================================================
        //--- var assessment = await ViqCrudService.GetSingleAsync<AssessmentDto>("tblAssessment", new{AssessmentId}); ---single parameter
        //--- var assessment = await ViqCrudService.GetSingleAsync<AssessmentDto>("tblAssessment",new {AssessmentId, Active = true}); ---- multiple parameters

        public async Task<T?> GetSingleAsync<T>(string tableName, object conditions)
        {
            await AuthorizeAssessmentParametersAsync(
                tableName, conditions, TenantRecordAccess.Read);

            ValidateSqlIdentifier(tableName);

            string whereClause = BuildWhereClause(conditions);

            string sql = $@"SELECT * FROM {SafeIdentifier(tableName)} WHERE {whereClause};";


            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                return await connection.QuerySingleOrDefaultAsync<T>(sql, conditions);
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        //---- GETS LIST OF RECORDS USING SINGLE OR MULTIPLE CONDITIONS, WITH ORDERING OPTIONS
        // ------USAGE ------ multiple conditions with ordering
        //  var businesses =  await ViqCrudService.GetListAsync<BusinessDto>("tblBusiness", 
        //                                                    new
        //                                                    {
        //                                                        ProvinceId,
        //                                                        Active = true
        //                                                    },
        //                                                    "BusinessName");
        //


        public async Task<IEnumerable<T>> GetListAsync<T>(string tableName,
                                                          object conditions,
                                                          string? orderBy = null,
                                                          bool ascending = true)
        {
            await AuthorizeAssessmentParametersAsync(
                tableName, conditions, TenantRecordAccess.Read);
            ValidateSqlIdentifier(tableName);
            string whereClause = BuildWhereClause(conditions);

            string sql = $@"SELECT * FROM {SafeIdentifier(tableName)} WHERE {whereClause}";
            if (!string.IsNullOrWhiteSpace(orderBy))
            {
                ValidateSqlIdentifier(orderBy);
                sql += $@" ORDER BY {SafeIdentifier(orderBy)} {(ascending ? "ASC" : "DESC")}";
            }

            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                return await connection.QueryAsync<T>(sql, conditions);
            }
            catch (Exception)
            {
                throw;
            }
        }


        private static string BuildWhereClause(object conditions)
        {
            if (conditions == null)
                throw new ArgumentNullException(nameof(conditions));

            var properties = conditions.GetType().GetProperties();

            if (properties.Length == 0)
                throw new ArgumentException(
                    "At least one condition must be supplied.");

            return string.Join(
                " AND ",
                properties.Select(property =>
                {
                    ValidateSqlIdentifier(property.Name);

                    return $"{SafeIdentifier(property.Name)} = @{property.Name}";
                }));
        }
        #endregion 





        // GENERIC RUN SQL METHODS 
        // Example usage: var count = await repo.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM Farmers");
        public async Task<T> ExecuteScalarAsync<T>(string sql, object parameters = null)
        {
            await AuthorizeAssessmentParametersAsync(
                sql, parameters, TenantRecordAccess.Read);
            try
            {
                using var connection = _dbConnectionFactory.CreateConnection();
                return await connection.ExecuteScalarAsync<T>(sql, parameters);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        // Generic method to execute commands (INSERT/UPDATE/DELETE)
        // Example usage: await repo.ExecuteCommandAsync("UPDATE Farmers SET Name = @Name WHERE Id = @Id", new { Name = "John", Id = 1 });
        public async Task<int> ExecuteCommandAsync(string sql, object parameters = null)
        {
            await AuthorizeAssessmentParametersAsync(
                sql, parameters, TenantRecordAccess.Write);
            using var connection = _dbConnectionFactory.CreateConnection();
            if (connection.State != ConnectionState.Open) connection.Open();

            using var transaction = connection.BeginTransaction();

            try
            {
                var rowsAffected = await connection.ExecuteAsync(sql, parameters, transaction);
                transaction.Commit();
                return rowsAffected;
            }
            catch (Exception)
            {
                transaction.Rollback();
                throw;
            }
        }


        //================================ GENERIC HELPER METHODS SECTION - RECORDEXISTS/COUNT RECORDS/GET FIELD/ ETC


        //1. ===================  check if record exists ==================
        public async Task<bool> RecordExistsAsync(string tableName, string keyFieldName, object keyValue)
        {
            await AuthorizeAssessmentKeyAsync(
                tableName, keyFieldName, keyValue, TenantRecordAccess.Read);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(keyFieldName);


            string sql = $@"SELECT CASE
                        WHEN EXISTS
                        (
                            SELECT 1 FROM {tableName} WHERE {keyFieldName}=@parKeyValue
                        )
                        THEN CAST(1 AS bit)
                        ELSE CAST(0 AS bit)
                        END";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<bool>(sql,
                new
                {
                    parKeyValue = keyValue
                });
        }


        //2. ======================== DLOOKUP ======================================================================
        // usage examples
        //string? clientName =  await ViqCrudService.LookupAsync<string>( "tblClient", "ClientName", "ClientId",clientId);
        //decimal vatRate = await ViqCrudService.LookupAsync<decimal>( "tblAssessment", "VATRate", "AssessmentId", AssessmentId);
        public async Task<T?> LookAsync<T>(string tableName, string returnField, string keyField, object keyValue)
        {
            await AuthorizeAssessmentKeyAsync(
                tableName, keyField, keyValue, TenantRecordAccess.Read);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(returnField);
            ValidateSqlIdentifier(keyField);


            string sql = $@"SELECT TOP(1) {returnField} FROM {tableName} WHERE {keyField}= @parKeyValue";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<T>(
                sql,
                new { parKeyValue = keyValue }
                );
        }



        //3. ===================== Count records meeting a key criteria ===================================== CountAsync
        public async Task<int> CountAsync(string tableName, string? keyField = null, object? keyValue = null)
        {
            await AuthorizeAssessmentKeyAsync(
                tableName, keyField, keyValue, TenantRecordAccess.Read);
            ValidateSqlIdentifier(tableName);

            string sql;
            object? parameters = null;

            if (string.IsNullOrWhiteSpace(keyField))
            {
                sql = $"SELECT COUNT(*) FROM {tableName}";
            }
            else
            {
                sql = $@" SELECT COUNT(*) FROM {tableName} WHERE {keyField}= @parKeyValue";
                parameters = new
                {
                    parKeyValue = keyValue
                };
            }

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<int>(sql, parameters);
        }


        //4. ===================== Sum records meeting a key criteria ===================================== SumAsync
        public async Task<decimal> SumAsync(string tableName,
                                            string fieldName,
                                            string? keyField = null,
                                            object? keyValue = null)
        {
            await AuthorizeAssessmentKeyAsync(
                tableName, keyField, keyValue, TenantRecordAccess.Read);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(fieldName);

            string sql;
            object? parameters = null;

            if (string.IsNullOrWhiteSpace(keyField))
            {
                sql = $@"SELECT ISNULL(SUM({fieldName}),0) FROM {tableName}";
            }
            else
            {
                sql = $@"SELECT ISNULL(SUM({fieldName}),0) FROM {tableName} WHERE {keyField}= @parKeyValue";
                parameters = new
                {
                    KeyValue = keyValue
                };
            }

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<decimal>(sql, parameters);
        }


        //5. ===================== Min records meeting a key criteria ===================================== MinAsync
        public async Task<T?> MinAsync<T>(string tableName, string fieldName)
        {
            await RejectUnscopedAssessmentQueryAsync(tableName);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(fieldName);

            string sql = $"SELECT MIN({fieldName}) FROM {tableName}";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<T>(sql);
        }


        //6. ===================== Max records meeting a key criteria ===================================== MaxAsync
        public async Task<T?> MaxAsync<T>(string tableName, string fieldName)
        {
            await RejectUnscopedAssessmentQueryAsync(tableName);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(fieldName);

            string sql = $"SELECT MAX({fieldName}) FROM {tableName}";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<T>(sql);
        }


        //7. ===================== Average records meeting a key criteria ===================================== AverageAsync
        public async Task<decimal> AverageAsync(string tableName, string fieldName)
        {
            await RejectUnscopedAssessmentQueryAsync(tableName);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(fieldName);

            string sql = $"SELECT ISNULL(AVG({fieldName}),0) FROM {tableName}";

            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteScalarAsync<decimal>(sql);
        }


        //8. ===================== Update 1 field meeting a key criteria ===================================== UpdateFieldAsync
        public async Task<int> UpdateFieldAsync(string tableName,
                                                string updateField,
                                                object updateValue,
                                                string keyField,
                                                object keyValue)
        {
            await AuthorizeAssessmentKeyAsync(
                tableName, keyField, keyValue, TenantRecordAccess.Write);
            ValidateSqlIdentifier(tableName);
            ValidateSqlIdentifier(updateField);
            ValidateSqlIdentifier(keyField);

            string sql = $@"UPDATE {tableName} SET {updateField}= @parUpdateValue WHERE {keyField}= @parKeyValue";

            using var connection = _dbConnectionFactory.CreateConnection();

            return await connection.ExecuteAsync(
                sql,
                new
                {
                    parUpdateValue = updateValue,
                    parKeyValue = keyValue
                });
        }

        //8. ===================== Execute sql ===================================== UpdateFieldAsync
        public async Task<int> ExecuteAsync(string sql, object? parameters = null)
        {
            await AuthorizeAssessmentParametersAsync(
                sql, parameters, TenantRecordAccess.Write);
            using var connection = _dbConnectionFactory.CreateConnection();
            return await connection.ExecuteAsync(sql, parameters);
        }

        private async Task AuthorizeAssessmentKeyAsync(
            string resource,
            string? keyField,
            object? keyValue,
            TenantRecordAccess access)
        {
            if (!IsAssessmentResource(resource))
            {
                return;
            }

            if (string.Equals(keyField, "AssessmentId", StringComparison.OrdinalIgnoreCase)
                && TryConvertToPositiveLong(keyValue, out var assessmentId))
            {
                await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                    assessmentId, access);
                return;
            }

            var values = keyField is null
                ? null
                : new Dictionary<string, object> { [keyField] = keyValue! };
            await AuthorizeAssessmentParametersAsync(resource, values, access);
        }

        private async Task AuthorizeAssessmentParametersAsync(
            string resource,
            object? parameters,
            TenantRecordAccess access)
        {
            if (!IsAssessmentResource(resource))
            {
                return;
            }

            if (TryReadPositiveLong(parameters, "AssessmentId", out var assessmentId))
            {
                await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                    assessmentId, access);
                return;
            }

            foreach (var mapping in AssessmentRecordKeys)
            {
                if (!TryReadPositiveLong(parameters, mapping.Key, out var recordId))
                {
                    continue;
                }

                using var connection = _dbConnectionFactory.CreateConnection();
                var parentAssessmentId = await connection.QuerySingleOrDefaultAsync<long?>(
                    $"""
                    SELECT AssessmentId
                    FROM [{mapping.Value.Table}]
                    WHERE [{mapping.Value.Key}] = @RecordId;
                    """,
                    new { RecordId = recordId });
                if (!parentAssessmentId.HasValue)
                {
                    throw new KeyNotFoundException(
                        $"The selected {mapping.Key} record does not exist.");
                }

                await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                    parentAssessmentId.Value, access);
                return;
            }

            throw new UnauthorizedAccessException(
                "Assessment SQL requires an authorised AssessmentId or supported child-record identifier.");
        }

        private async Task AuthorizeReturnedEntityAsync<T>(
            T? entity,
            TenantRecordAccess access)
            where T : class
        {
            if (entity is null
                || !TryReadPositiveLong(entity, "AssessmentId", out var assessmentId))
            {
                return;
            }

            await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                assessmentId, access);
        }

        private async Task AuthorizeReturnedEntitiesAsync<T>(
            IEnumerable<T> entities,
            TenantRecordAccess access)
            where T : class
        {
            foreach (var assessmentId in entities
                .Select(entity => TryReadPositiveLong(entity, "AssessmentId", out var id) ? id : 0)
                .Where(id => id > 0)
                .Distinct())
            {
                await _tenantAuthorizationService.EnsureCanAccessAssessmentAsync(
                    assessmentId, access);
            }
        }

        private Task RejectUnscopedAssessmentQueryAsync(string resource)
        {
            if (IsAssessmentResource(resource))
            {
                throw new UnauthorizedAccessException(
                    "Unscoped aggregate queries are not permitted for assessment data.");
            }

            return Task.CompletedTask;
        }

        private static bool IsAssessmentResource(string resource) =>
            AssessmentResourceNames.Any(name =>
                resource.Contains(name, StringComparison.OrdinalIgnoreCase));

        private static bool TryReadPositiveLong(
            object? source,
            string propertyName,
            out long value)
        {
            value = 0;
            if (source is null)
            {
                return false;
            }

            object? rawValue = null;
            if (source is IReadOnlyDictionary<string, object> readOnlyDictionary)
            {
                var item = readOnlyDictionary.FirstOrDefault(pair =>
                    IsParameterName(pair.Key, propertyName));
                rawValue = item.Value;
            }
            else if (source is IDictionary<string, object> dictionary)
            {
                var item = dictionary.FirstOrDefault(pair =>
                    IsParameterName(pair.Key, propertyName));
                rawValue = item.Value;
            }
            else
            {
                rawValue = source.GetType().GetProperties()
                    .FirstOrDefault(property =>
                        IsParameterName(property.Name, propertyName))
                    ?.GetValue(source);
            }

            return TryConvertToPositiveLong(rawValue, out value);
        }

        private static bool TryConvertToPositiveLong(object? source, out long value)
        {
            try
            {
                value = source is null ? 0 : Convert.ToInt64(source);
                return value > 0;
            }
            catch (Exception) when (source is not null)
            {
                value = 0;
                return false;
            }
        }

        private static bool IsParameterName(string candidate, string expected) =>
            candidate.Equals(expected, StringComparison.OrdinalIgnoreCase)
            || candidate.Equals($"par{expected}", StringComparison.OrdinalIgnoreCase);

        private static readonly string[] AssessmentResourceNames =
        [
            "tblAssessments",
            "tblAssessmentAssets",
            "tblAssessmentAssetMovement",
            "tblAssessmentExpenses",
            "tblAssessmentSales",
            "tblAssessmentStock",
            "tblAssessmentCashBook",
            "tblAssessmentLoan",
            "tblAssessmentLoanRepayment",
            "tblAssessmentProjectionAssumptions",
            "tblAssessmentSalesCategory",
            "tblAssessmentWorkingCapitalDetail",
            "tblAssessmentIncomeStatement",
            "tblAssessmentVATTransactions",
            "tblAssessmentDebtorsCreditorsProfile",
            "tblAssessmentReviews",
            "vw_assessment",
            "tblCashflowSummary",
            "tblDebtorPaymentSchedule",
            "tblDebtorsConfiguration"
        ];

        private static readonly IReadOnlyDictionary<string, (string Table, string Key)>
            AssessmentRecordKeys =
                new Dictionary<string, (string Table, string Key)>(
                    StringComparer.OrdinalIgnoreCase)
                {
                    ["AssessmentAssetId"] =
                        ("tblAssessmentAssets", "AssessmentAssetId"),
                    ["AssessmentLoanId"] =
                        ("tblAssessmentLoan", "AssessmentLoanId"),
                    ["AssessmentStockId"] =
                        ("tblAssessmentStock", "AssessmentStockId"),
                    ["AssessmentExpensesId"] =
                        ("tblAssessmentExpenses", "AssessmentExpensesId"),
                    ["AssessmentSalesId"] =
                        ("tblAssessmentSales", "AssessmentSalesId")
                };



    }
}
